IGAB export of "Sample Household" — Feb 2024 to Aug 2026.

This file is YNAB-shaped on purpose: the Register and Plan members
read in the format YNAB exports, so a spreadsheet opens them and
IGAB's own YNAB importer reads them back.

WHAT IS NOT IN THIS FILE
  - Attachments: Receipt images and PDFs.
  - Undo history: The change log, and the ability to undo anything in it.
  - Views and filters: Saved budget views and saved register filters.
  - Reconciliation history: Statement balances from past reconciliations.
  - AI history: Queued and completed AI jobs.
  - Guide and wishlist: Roadmap answers, bindings, and wishlist items.
  - Approval state: Whether a transaction had been reviewed.

If you need any of the above, take a budget snapshot instead
(Settings -> Budget Backups). A snapshot is exact and lossless; this
export is readable and portable. They answer different questions.

A credit card's payment envelope shows no Activity figure. What IGAB
holds there is money set aside to pay the card, not spending filed to
that category — the register shows a card payment as a transfer. Its
assigned and available figures are real and are included.

Income categories show Activity only. IGAB blanks their assigned and
available figures on screen for the same reason: a lifetime income
total under a "free to assign" heading is not a fact about money you
can spend.
